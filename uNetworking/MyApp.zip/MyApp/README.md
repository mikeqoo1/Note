# 說明

1. npm i
2. node test-uws.js
3. curl http://localhost:9001/
